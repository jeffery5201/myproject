package p5;

public class p5 {

	public static void main(String[] args) {
		Car car1;
		car1=new Car();

	}

}

class Car{
	//Car���O
}