package p12;

public class p12 {

	public static void main(String[] args) {
		Car car1;
		car1=new Car();
		
		car1.num=1234;
		car1.gas=20.5;
		
		Car car2;
		car2=new Car();
		/*
		car2.num=2345;
		car2.gas=30.5;
		*/
		
		car1.showCar();
		/*
		System.out.println("");
		car2.showCar();
		*/
	}

}

class Car
{
	int num;
	double gas;
	
	void show() {
		System.out.println("�����O"+this.num);
		System.out.println("�T�o�q�O"+this.gas);
	}
	void showCar() {
		System.out.println("�}�l��ܨ��l���");
		show();
	}
}