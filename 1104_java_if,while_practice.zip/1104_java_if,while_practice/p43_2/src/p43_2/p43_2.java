package p43_2;

public class p43_2 {

	public static void main(String[] args) {
		int[]test= {80,60,22,50,75};
		
		for(int i=0;i<test.length;i++) {
			System.out.println("��"+(i+1)+"�ӤH�����ƬO"+test[i]+"��");
		}
		System.out.println("�ҸդH�Ƭ�"+test.length+"�H");
	}

}
