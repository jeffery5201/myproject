package pb;

public class test_p10 {

	public static void main(String[] args) {
		pc.Car car1=new pc.Car();
		car1.show();

	}

}
